﻿using Secure.Logic.Utils;
using System.Collections.Generic;
using System.Linq;

namespace Secure.Logic.Client.API
{
    public class ClientSession
    {
        private static Dictionary<string, SignatureInfo> si = new Dictionary<string, SignatureInfo>();

        public static void Put(string cuID, SignatureInfo si)
        {
            if (!ClientSession.si.Keys.Contains(cuID))
            {
                ClientSession.si.Add(cuID, si);
            }
            else
            {
                ClientSession.si[cuID] = si;
            }
        }

        public static bool Exist(string cuID)
        {
            return ClientSession.si.Keys.Contains(cuID);
        }

        public static SignatureInfo Get(string cuID)
        {
            return ClientSession.si[cuID];
        }
    }
}
