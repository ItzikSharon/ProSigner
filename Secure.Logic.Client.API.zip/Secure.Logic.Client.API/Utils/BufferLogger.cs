﻿using System;
using System.IO;
using System.Reflection;
using System.Text;

namespace Secure.Logic.Client.API.Utils
{
    public class BufferLogger 
    {
        private const string DATETIME_FORMAT = "yyyy-MM-dd HH:mm:ss.fff";
        public enum LOG_LEVEL { NORMAL = 0, VERBOSE = 1, DEBUG = 2 }

        public class LoggerSettings
        {
            public LOG_LEVEL currentLogLevel = LOG_LEVEL.DEBUG;
            public bool Enabled { get; set; }
            public string Path { get; set; }
            public int Interval { get; set; }

        }

        public LoggerSettings Settings { get; set; } = new LoggerSettings();
        public string logFilename { get; set; }
        public StringBuilder sb { get; set; } = new StringBuilder(4 * 1024); // 4MB memory 

        private static BufferLogger instance = null;

        public static BufferLogger getInstance()
        {
            if (instance == null)
            {
                instance = new BufferLogger();
                instance.Init();
            }
            return instance;
        }

        private void Init()
        {
            //-- Set Log Path;
            Settings.Path = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) + @"\Logs";

            //-- Get Log: Enabled: if exists Logs folder in this direcory
            Settings.Enabled = Directory.Exists(this.Settings.Path);

            //-- Get Log: Level
            Settings.currentLogLevel = LOG_LEVEL.DEBUG;

            //-- Get Log: Interval
            Settings.Interval = 2;
        }

        public void toLog(string msg)
        {
            this.toLog(msg, LOG_LEVEL.DEBUG);
        }

        public void toLog(string msg, LOG_LEVEL level)
        {
            if (Settings.Enabled)
                if (this.Settings.currentLogLevel >=level)
                {
                    sb.AppendFormat("{0} [{1}]-{2} \n", DateTime.Now.ToString(DATETIME_FORMAT), level, msg);
                    if ((sb.Length / 80) > Settings.Interval)
                    {
                        if (DumpToFile())
                            Clear();
                    }
                }
        }


        public void Clear()
        {
            sb.Clear();
        }

        public string Dump()
        {
            return sb.ToString();
        }
        private bool DumpToFile()
        {
            if (!string.IsNullOrEmpty(Settings.Path))
            {
   
                logFilename = Settings.Path + @"\"  + DateTime.Now.ToString("yyyyMMdd") + ".log";
                if (!Directory.Exists(Settings.Path))
                    Directory.CreateDirectory(Settings.Path);
                try
                {
                    using (System.IO.StreamWriter writer = new System.IO.StreamWriter(logFilename, true, System.Text.Encoding.UTF8))
                    {
                        writer.WriteLine(string.Format("====================== DUMP ==============================="));
                        writer.Write(sb.ToString());
                    }
                }
                catch 
                {
                    return false;
                }
            }

            return true;
        } 
    }
}
