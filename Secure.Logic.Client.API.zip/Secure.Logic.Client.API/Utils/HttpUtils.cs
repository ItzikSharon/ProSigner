﻿using System.Collections.Specialized;
using System.IO;
using System;
using System.Net;
using System.Net.Http;
using System.Text;
using Secure.Logic.Client.API.Exceptions;

namespace Secure.Logic.Client.API.Utils
{
    public class HttpUtils
    {
        static HttpClient client = new HttpClient();

        public static string Get(string url)
        {
            try
            {
                WebClient client = new WebClient();
                Stream data = client.OpenRead(url);
                StreamReader reader = new StreamReader(data);
                string s = reader.ReadToEnd();
                data.Close();
                reader.Close();
                return s;
            }
            catch (Exception ex)
            {
                throw new APIException(Logic.Utils.ErrorCodes.GENERIC_CODE.GENERAL_ERROR, Logic.Utils.ErrorCodes.SPECIFIC_CODES.GENERAL_ERROR,  "Unable to perform Get to url " + url + " " + ex.Message);
            }
         
        }

        public static string Post(string url)
        {
            try
            {
                using (var client = new WebClient())
                {
                    var data = new NameValueCollection();
                    var response = client.UploadValues(url, "Post", data);
                    var responseString = Encoding.Default.GetString(response);
                    return responseString;
                }
            }
            catch (Exception ex)
            {
                throw new APIException(Logic.Utils.ErrorCodes.GENERIC_CODE.GENERAL_ERROR, Logic.Utils.ErrorCodes.SPECIFIC_CODES.GENERAL_ERROR, "Unable to perform Get to url " + url + " " + ex.Message);
            }
            
        }

    }
}
