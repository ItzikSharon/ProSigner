﻿using Secure.Logic.Client.API.DigiSign;
using Secure.Logic.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Secure.Logic.Client.API.Utils
{
    public class Utils
    {
        public static string GetValueOrDefault(string value, string defaultVal)
        {
            
            if (value == null)
            {
                return defaultVal;
            }

            return value; ;
        }
        public static int GetValueOrDefault(int value, int defaultVal)
        {

            if (value < 0 /*|| value > 1024  << this limitation check is not good for A3, removed in version 4.3*/ )
            {
                return defaultVal;
            }

            return value;
        }


        public static void InitFromSigInfo(SigFormat sigFormat,  SignatureInfo sigInfo)
        {

            sigInfo.Reason = Utils.GetValueOrDefault(sigFormat.Reason, sigInfo.Reason);
            sigInfo.Contact = Utils.GetValueOrDefault(sigFormat.Contact, sigInfo.Contact);
            sigInfo.Location = Utils.GetValueOrDefault(sigFormat.Location, sigInfo.Location);
            sigInfo.sigpage = Utils.GetValueOrDefault(sigFormat.sigpage, sigInfo.sigpage);
            sigInfo.ImageBase64 = Utils.GetValueOrDefault(sigFormat.ImageBase64, sigInfo.ImageBase64);
            sigInfo.llx = Utils.GetValueOrDefault(sigFormat.llx, sigInfo.llx);
            sigInfo.lly = Utils.GetValueOrDefault(sigFormat.lly, sigInfo.lly);
            sigInfo.urx = Utils.GetValueOrDefault(sigFormat.urx, sigInfo.urx);
            sigInfo.ury = Utils.GetValueOrDefault(sigFormat.ury, sigInfo.ury);

            sigInfo.ImageOnly = sigFormat.ImageOnly;

        }
    }
}
