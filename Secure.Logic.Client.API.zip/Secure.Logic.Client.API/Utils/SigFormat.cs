﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Secure.Logic.Client.API.Utils
{
    public class SigFormat
    {
        public string Location { get; set; }
        public string Reason { get; set; }
        public string sigpage { get; set; }
        public string Contact { get; set; }
        public string ImageBase64 { get; set; }
        public int llx { get; set; }
        public int lly { get; set; }
        public int urx { get; set; }
        public int ury { get; set; }
        public int ImageOnly { get; set; }

    }
}
