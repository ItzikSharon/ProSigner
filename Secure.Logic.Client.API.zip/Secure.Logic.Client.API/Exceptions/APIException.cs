﻿using Secure.Logic.Utils;
using System;
using System.Text;

namespace Secure.Logic.Client.API.Exceptions
{
    public class APIException : Exception
    {
        public ErrorCodes.GENERIC_CODE GenericCode { get; set; } = ErrorCodes.GENERIC_CODE.GENERAL_ERROR;
        public ErrorCodes.SPECIFIC_CODES SpecificCode { get; set; } = ErrorCodes.SPECIFIC_CODES.GENERAL_ERROR;
        public string ErrorExtendedInformation { get; set; }  = String.Empty;
        public APIException(ErrorCodes.GENERIC_CODE GenericCode, ErrorCodes.SPECIFIC_CODES SpecificCode, string ErrorExtendedInformation)
        {
            this.GenericCode = GenericCode;
            this.SpecificCode = SpecificCode;
            this.ErrorExtendedInformation = ErrorExtendedInformation;
        }
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("[Generic Error Code=");
            sb.Append("" + this.GenericCode);
            sb.Append("],[Specific Error Code=");
            sb.Append("" + SpecificCode + "]");
            if (String.IsNullOrEmpty(this.ErrorExtendedInformation))
            {
                sb.Append(",[Extended Information=" + this.ErrorExtendedInformation + "]");
            }
            sb.AppendLine();

            return sb.ToString();

        }
    }
}
