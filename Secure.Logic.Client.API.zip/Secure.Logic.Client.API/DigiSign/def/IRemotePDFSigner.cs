﻿using iTextSharp.text.pdf;
using Secure.Logic.Client.API;
using Secure.Logic.Utils;
using System.Collections.Generic;

namespace Secure.Logic.Client.API.DigiSign
{
    interface IRemotePDFSigner
    {
        byte[] sign(byte[] fileBuffer, SignatureInfo sigInfo, RemoteSigWSData wsData);
    }
}
