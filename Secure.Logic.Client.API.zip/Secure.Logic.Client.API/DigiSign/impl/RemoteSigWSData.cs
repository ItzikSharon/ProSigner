﻿namespace Secure.Logic.Client.API.DigiSign
{
    public class RemoteSigWSData
    {
        public string token { get; set; }
        public string callerid { get; set; }
        public string cryptoUserID { get; set; }
        public string pin { get; set; }
        public string FileName { get; set; }
        public string SigType { get; set; }
        public string activeServerBaseURL { get; set; }
        public string noneActiveServerBaseURL { get; set; }

    }
}