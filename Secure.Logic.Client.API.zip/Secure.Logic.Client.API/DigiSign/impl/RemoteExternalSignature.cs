﻿using System;
using iTextSharp.text.pdf.security;
using Org.BouncyCastle.Asn1;
using Org.BouncyCastle.Asn1.X509;
using Org.BouncyCastle.Crypto;
using Org.BouncyCastle.Crypto.Digests;
using Secure.Logic.Util;
using Secure.Logic.Utils;
using System.Net.Http;
using System.Collections.Generic;
using System.Threading.Tasks;
using Secure.Logic.Client.API.Utils;
using Secure.Logic.Client.API.Exceptions;
using Newtonsoft.Json;

namespace Secure.Logic.Client.API.DigiSign
{
    public enum HashAlgorithm
    {
        /// <summary>
        /// The SHA1 hash algorithm
        /// </summary>
        SHA1,

        /// <summary>
        /// The SHA256 hash algorithm
        /// </summary>
        SHA256,

        /// <summary>
        /// The SHA384 hash algorithm
        /// </summary>
        SHA384,

        /// <summary>
        /// The SHA512 hash algorithm
        /// </summary>
        SHA512
    }



    class RemoteExternalSignature : IExternalSignature
    {
        private HashAlgorithm hashAlgorithm = HashAlgorithm.SHA256;

        private RemoteSigWSData wsData;

        private static Object LOCK = new Object();


        public RemoteExternalSignature(RemoteSigWSData wsData)
        {
            this.wsData = wsData;
        }

        public string GetEncryptionAlgorithm()
        {
            return "RSA";
        }

        public string GetHashAlgorithm()
        {
            return hashAlgorithm.ToString();
        }

        private byte[] CreateDigestInfo(byte[] hash, string hashOid)
        {
            DerObjectIdentifier derObjectIdentifier = new DerObjectIdentifier(hashOid);
            AlgorithmIdentifier algorithmIdentifier = new AlgorithmIdentifier(derObjectIdentifier, null);
            DigestInfo digestInfo = new DigestInfo(algorithmIdentifier, hash);
            return digestInfo.GetDerEncoded();
        }



        private byte[] ComputeDigest(IDigest digest, byte[] data)
        {
            if (digest == null)
                throw new ArgumentNullException("digest");

            if (data == null)
                throw new ArgumentNullException("data");

            byte[] hash = new byte[digest.GetDigestSize()];

            digest.Reset();
            digest.BlockUpdate(data, 0, data.Length);
            digest.DoFinal(hash, 0);

            return hash;
        }


        public byte[] Sign(byte[] message)
        {
            
            lock (LOCK)
            {

                try
                {
                    //-- Log
                    BufferLogger.getInstance().toLog("@RemoteExternalSignature.Sign");

                    byte[] digest = null;
                    byte[] digestInfo = null;

                    switch (this.hashAlgorithm)
                    {
                        case HashAlgorithm.SHA1:
                            digest = ComputeDigest(new Sha1Digest(), message);
                            digestInfo = CreateDigestInfo(digest, "1.3.14.3.2.26");
                            break;
                        case HashAlgorithm.SHA256:
                            digest = ComputeDigest(new Sha256Digest(), message);
                            digestInfo = CreateDigestInfo(digest, "2.16.840.1.101.3.4.2.1");
                            break;
                        case HashAlgorithm.SHA384:
                            digest = ComputeDigest(new Sha384Digest(), message);
                            digestInfo = CreateDigestInfo(digest, "2.16.840.1.101.3.4.2.2");
                            break;
                        case HashAlgorithm.SHA512:
                            digest = ComputeDigest(new Sha512Digest(), message);
                            digestInfo = CreateDigestInfo(digest, "2.16.840.1.101.3.4.2.3");
                            break;
                    }

                    //-- Print the digest info
                    string hex = BitConverter.ToString(digestInfo);

                    //using (var client = new HttpClient())
                    //{
                    HttpClient client = new HttpClient();
                    MultipartFormDataContent content = null;

                    // Add form values 
                    var formValues = new[]  {
                    new KeyValuePair<string, string>("token", wsData.token),
                    new KeyValuePair<string, string>("callerid", wsData.callerid),
                    new KeyValuePair<string, string>("filename", wsData.FileName),
                    new KeyValuePair<string, string>("cuid", wsData.cryptoUserID),
                    new KeyValuePair<string, string>("pin", wsData.pin),
                    new KeyValuePair<string, string>("digest", hex)};

                    string rv = null;



                    //  CALL THE PRIMARY SERVER SIGN METHOD 
                    // Make a call to Web API


                    HttpResponseMessage response = null;

                    try
                    {
                        BufferLogger.getInstance().toLog("Try to connect to ACTIVE server at: " + wsData.activeServerBaseURL);

                        content = new MultipartFormDataContent();
                        foreach (var keyValuePair in formValues)
                            content.Add(new StringContent(keyValuePair.Value), keyValuePair.Key);


                        client.BaseAddress = new Uri(wsData.activeServerBaseURL);
                        response = client.PostAsync("api/sign/fastsign", content).Result;
                    }catch(Exception e) // Primary server call faild, try to the other server
                    {
                        BufferLogger.getInstance().toLog("Primary server is down!");
                        try
                        {
                            if (wsData.noneActiveServerBaseURL != null){

                                content = new MultipartFormDataContent();
                                client = new HttpClient();
                                foreach (var keyValuePair in formValues)
                                    content.Add(new StringContent(keyValuePair.Value), keyValuePair.Key);

                                BufferLogger.getInstance().toLog("Try to connect to NONE ACTIVE server at: " + wsData.noneActiveServerBaseURL);
                                client.BaseAddress = new Uri(wsData.noneActiveServerBaseURL);
                                response = client.PostAsync("api/sign/fastsign", content).Result;
                            }
                        }
                        catch(Exception e3)
                        {
                            BufferLogger.getInstance().toLog("Secondary server is down!");
                        }
                    }

                    if (response!= null && response.IsSuccessStatusCode)
                    {

                        Task<String> t = response.Content.ReadAsStringAsync();
                        t.Wait();
                        string json = t.Result;
                        APIExtendedResult apiResult = JsonConvert.DeserializeObject<APIExtendedResult>(json);
                        if(apiResult.IsSuccess())
                        {
                            string base64HashedValue = apiResult.Values["SIGRESULT"];
                            byte[] b = Convert.FromBase64String(base64HashedValue);
                            return b;
                        }else
                        {

                            throw new APIException(apiResult.GenericCode, apiResult.SpecificCode, apiResult.ErrorExtendedInformation);
                        }

                        ////rv = rv.Replace("\"", string.Empty);
                        ////APIResult result = new APIResult(rv);

                        ////if (result.IsSuccess())
                        ////{
                        ////    string base64HashedValue = result.getValue();
                        ////    byte[] b = Convert.FromBase64String(base64HashedValue);
                        ////    return b;
                        ////}
                        ////else
                        ////{
                        ////    throw new APIException(result.GetResultCode(), result.getDescription());
                        ////}

                        // Parse extende result as JSON 

                    }
                }
                catch (APIException ex)
                {
                    throw ex;
                }
                catch (Exception ex)
                {
                    throw new APIException(ErrorCodes.GENERIC_CODE.GENERAL_ERROR , ErrorCodes.SPECIFIC_CODES.GENERAL_ERROR, ex.Message);
                }

                return null;
            }
        }
    }
}
