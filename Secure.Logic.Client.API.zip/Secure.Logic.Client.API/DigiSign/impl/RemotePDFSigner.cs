﻿using iTextSharp.text;
using iTextSharp.text.pdf;
using iTextSharp.text.pdf.security;
using Secure.Logic.Client.API.Exceptions;
using Secure.Logic.Client.API.Utils;
using Secure.Logic.Utils;
using System;
using System.IO;
using static iTextSharp.text.Font;

namespace Secure.Logic.Client.API.DigiSign
{
    class RemotePDFSigner : IRemotePDFSigner
    {
        public byte[] sign(byte[] fileBuffer, SignatureInfo sigInfo, RemoteSigWSData wsData)
        {
            BufferLogger.getInstance().toLog("@RemotePDFSigner.sign");
            try
            {

                using (PdfReader pdfReader = new PdfReader(fileBuffer))
                {

                    // Create output stream for signed PDF document
                    using (MemoryStream outputStream = new MemoryStream())

                    {

                        string currentDateTime = DateTime.Now.ToString();

                        // Create PdfStamper that applies extra content to the PDF document
                        PdfStamper pdfStamper = PdfStamper.CreateSignature(pdfReader, outputStream, '\0', Path.GetTempFileName(), true);

                        PdfSignatureAppearance pdfSignatureAppeance = pdfStamper.SignatureAppearance;
                        if (sigInfo.ImageOnly == 0)
                        {
                            pdfSignatureAppeance.Reason = sigInfo.Reason;
                            pdfSignatureAppeance.Contact = sigInfo.Contact + "_" + currentDateTime;
                            // -- version 4.3  -- Add appearance and improve desing of the signature shown in the page 
                            pdfSignatureAppeance.Layer2Font = new Font(FontFamily.COURIER, 8, Font.BOLDITALIC);
                            pdfSignatureAppeance.Layer2Text = "\n\n\n" + "Signed By: " + sigInfo.Contact + "\n" + "Reason: " + sigInfo.Reason;
                        }


                        if (String.IsNullOrEmpty(sigInfo.sigpage))
                        {
                            sigInfo.sigpage = "last";
                        }

                        int pageNumber = 0;

                        if (sigInfo.sigpage == "first")
                        {
                            pageNumber = 1;
                        }
                        else
                        {
                            pageNumber = pdfReader.NumberOfPages;
                        }


                        iTextSharp.text.Rectangle Rectangle = new iTextSharp.text.Rectangle(sigInfo.llx, sigInfo.lly, sigInfo.urx, sigInfo.ury);

                        if (!string.IsNullOrEmpty(sigInfo.ImageBase64))
                        {
                            byte[] imageBytes = Convert.FromBase64String(sigInfo.ImageBase64);
                            pdfSignatureAppeance.SignatureGraphic = iTextSharp.text.Image.GetInstance(imageBytes);
                            if (sigInfo.ImageOnly == 1){
                                pdfSignatureAppeance.SignatureRenderingMode = PdfSignatureAppearance.RenderingMode.GRAPHIC; 
                            }else
                            {
                                pdfSignatureAppeance.SignatureRenderingMode = PdfSignatureAppearance.RenderingMode.GRAPHIC_AND_DESCRIPTION;
                            }
                        }
                        else
                        {
                            if (sigInfo.ImageOnly == 1)
                            {
                                pdfSignatureAppeance.SignatureRenderingMode = PdfSignatureAppearance.RenderingMode.GRAPHIC;
                            }
                            else
                            {
                                pdfSignatureAppeance.SignatureRenderingMode = PdfSignatureAppearance.RenderingMode.NAME_AND_DESCRIPTION;
                            }
                        }

                        // Bug name contains dot
                        string normelizedName = this.normelize(sigInfo.Contact);
                        pdfSignatureAppeance.SetVisibleSignature(Rectangle, pageNumber, normelizedName + "_" + currentDateTime);// this is for multiple signatures in a file 
                        RemoteExternalSignature extSig = new RemoteExternalSignature(wsData);
                        MakeSignature.SignDetached(pdfStamper.SignatureAppearance, extSig, sigInfo.Chain, null, null, null, 0, CryptoStandard.CMS);
                        
                        //-- get signed file as buffer
                        byte[] buffer = outputStream.ToArray();
                        pdfStamper.Close();
                        outputStream.Close();

                        //-- return
                        return buffer;
                    }
                }
            }
            catch(APIException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                
                throw new APIException(ErrorCodes.GENERIC_CODE.GENERAL_ERROR, ErrorCodes.SPECIFIC_CODES.GENERAL_ERROR, ex.Message);
            }
        }

        private string normelize(string contact)
        {
            
            if (String.IsNullOrEmpty(contact))
            {
                return String.Empty;
            }

            contact = contact.Replace(".", "_");
            return contact;

        }
    }
}
