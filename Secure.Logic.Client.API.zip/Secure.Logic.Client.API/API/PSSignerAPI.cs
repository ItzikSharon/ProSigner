﻿using Secure.Logic.Client.API.DigiSign;
using Secure.Logic.Util;
using Secure.Logic.Utils;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using Newtonsoft.Json;
using Org.BouncyCastle.X509;
using Secure.Logic.Client.API.Utils;
using Secure.Logic.Client.API.Exceptions;
using System.Threading.Tasks;

namespace Secure.Logic.Client.API
{
    public class PSSignerAPI
    {
        private string primaryServerURL { get; set; }
        private string secondaryServerURL { get; set; }

        private string activeServerURL { get; set; }
        private string noneActiveServerURL { get; set; }

        private static Object LOCK = new Object();



        public PSSignerAPI(string primaryServerURL, string secondaryServerURL = null)
        {
            BufferLogger.getInstance().toLog("@PSSignerAPI.PSSignerAPI");

            if (string.IsNullOrEmpty(primaryServerURL))
            {
                BufferLogger.getInstance().toLog("Invalid web service URL, URL is null or empty");
                throw new Exception("URL is null or empty");
            }

            this.primaryServerURL = primaryServerURL;
            BufferLogger.getInstance().toLog("Primary URL is set to: " + this.primaryServerURL);

            // Do not check the secondary server as it can be null
            this.secondaryServerURL = secondaryServerURL;
        }

        //public async Task<byte[]> SignRequest(
        //                            string Token,
        //                            string fileName,
        //                            string cuID,
        //                            string PIN,
        //                            string SigType,
        //                            byte[] fileIn
        //                        )
        //{
        //    using (var client = new HttpClient())
        //    {
        //        using (var content = new MultipartFormDataContent())
        //        {
        //            // Make sure to change API address
        //            client.BaseAddress = new Uri(url);

        //            URLParam tokenParam = URLParam.initFromDecoded(Token);
        //            URLParam fileNameParam = URLParam.initFromDecoded(fileName);
        //            URLParam userParam = URLParam.initFromDecoded(cuID);
        //            URLParam pinParam = URLParam.initFromDecoded(PIN);
        //            URLParam sigTypeParam = URLParam.initFromDecoded(SigType);


        //            // Add form values 
        //            var formValues = new[]  {
        //                new KeyValuePair<string, string>("token", tokenParam.encodedValue),
        //                new KeyValuePair<string, string>("filename", fileNameParam.encodedValue),
        //                new KeyValuePair<string, string>("cuid", userParam.encodedValue),
        //                new KeyValuePair<string, string>("pin", pinParam.encodedValue),
        //                new KeyValuePair<string, string>("sigtype", sigTypeParam.encodedValue)};

        //            foreach (var keyValuePair in formValues)
        //                content.Add(new StringContent(keyValuePair.Value), keyValuePair.Key);


        //            var file = new StreamContent(new MemoryStream(fileIn));
        //            file.Headers.ContentDisposition = new ContentDispositionHeaderValue("attachment");
        //            content.Add(file);

        //            HttpResponseMessage response = null;

        //            // Make a call to Web API
        //            try
        //            {
        //                response = await client.PostAsync("api/sign", content);

        //                //HttpResponseMessage response = client.PostAsync("api/sign", content).Result;

        //                if (response.IsSuccessStatusCode)
        //                {
        //                    return response.Content.ReadAsByteArrayAsync().Result;
        //                }
        //                else
        //                {
        //                    throw new Exception();
        //                }
        //            }catch
        //            {
        //                byte[] bytes = response.Content.ReadAsByteArrayAsync().Result;
        //                string error = System.Text.Encoding.UTF8.GetString(bytes);
        //                throw new Exception(error);
        //            }
        //        }
        //    }
        //}



        /**********************************************************************************************************************
        * 
        * Perform Fast Signature 
        * 
        **********************************************************************************************************************/
        public async System.Threading.Tasks.Task<byte[]> FastSignRequest(
                                    string Token,
                                    string callerid,
                                    string fileName,
                                    string cuID,
                                    string PIN,
                                    byte[] fileIn,
                                    SigFormat sigFormat
                                )
        {
            lock (LOCK)
            {
                try
                {

                    BufferLogger.getInstance().toLog("@PSSignerAPI.FastSignRequest");


                    if (String.IsNullOrEmpty(callerid))
                        callerid = "single";


                    BufferLogger.getInstance().toLog("Initialize Paramters...");

                    URLParam tokenURLParam = URLParam.initFromDecoded(Token);
                    URLParam callerIDURLParam = URLParam.initFromDecoded(callerid);
                    URLParam cryptoUserIDParam = URLParam.initFromDecoded(cuID);
                    URLParam pinURLParam = URLParam.initFromDecoded(PIN);
                    URLParam FileNameURLParam = URLParam.initFromDecoded(fileName);

                    SignatureInfo sigInfo = null;
                    RemotePDFSigner signer = new RemotePDFSigner();
                    RemoteSigWSData wsData = new RemoteSigWSData();

                    wsData.activeServerBaseURL = this.activeServerURL;
                    wsData.noneActiveServerBaseURL = this.noneActiveServerURL;

                    wsData.token = tokenURLParam.encodedValue;
                    wsData.callerid = callerIDURLParam.encodedValue;
                    wsData.cryptoUserID = cryptoUserIDParam.encodedValue;
                    wsData.pin = pinURLParam.encodedValue;
                    wsData.FileName = FileNameURLParam.encodedValue;
                    wsData.SigType = "0";

                    BufferLogger.getInstance().toLog("Done");


                    BufferLogger.getInstance().toLog("Check if client configuration session exists...");
                    if (!ClientSession.Exist(cuID))
                    {
                        BufferLogger.getInstance().toLog("SigInfo does not exist, calling getclientconfig...");

                        var client = new HttpClient();
                        client.DefaultRequestHeaders.Accept.Clear();
                        client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                        APIExtendedResult apiResult = null;

                        string json = null;

                        try // read config from primary server 
                        {
                            // Await this function call - do not continue until finish !
                            //json = await client.GetStringAsync(this.activeServerURL + "api/sign/config/" + tokenURLParam.encodedValue + "/" + cryptoUserIDParam.encodedValue);
                            Task <string> res = client.GetStringAsync(this.activeServerURL + "api/sign/config/" + tokenURLParam.encodedValue + "/" + cryptoUserIDParam.encodedValue);
                            res.Wait();
                            json = res.Result;

                            apiResult = JsonConvert.DeserializeObject<APIExtendedResult>(json);
                        }
                        catch (Exception e)
                        {
                            try
                            {
                                if (this.secondaryServerURL != null)
                                {
                                    // Await this function call - do not continue until finish !
                                    //json = await client.GetStringAsync(this.noneActiveServerURL + "api/sign/config/" + tokenURLParam.encodedValue + "/" + cryptoUserIDParam.encodedValue);

                                    Task<string> res = client.GetStringAsync(this.noneActiveServerURL + "api/sign/config/" + tokenURLParam.encodedValue + "/" + cryptoUserIDParam.encodedValue);
                                    res.Wait();
                                    json = res.Result;

                                    apiResult = JsonConvert.DeserializeObject<APIExtendedResult>(json);
                                }
                            }
                            catch (Exception e2)
                            {
                                throw new APIException(ErrorCodes.GENERIC_CODE.GENERAL_ERROR, ErrorCodes.SPECIFIC_CODES.API_UNABLE_TO_CONNECT_TO_SERVER, "Client API library was unable to connect to (both) server");
                            }
                        }

                        BufferLogger.getInstance().toLog("APIResult accepted successfully, checking result...");

                        //check the raw result before parsing to avoid exceptoins 
                        if (!(apiResult.IsSuccess()))
                        {
                            BufferLogger.getInstance().toLog("APIResult contains result error, throwing exception");
                            throw new APIException(apiResult.GenericCode, apiResult.SpecificCode, apiResult.ErrorExtendedInformation);
                        }
                        else
                        {
                            BufferLogger.getInstance().toLog("APIResult contains result success, continue...");
                            if (apiResult.Values == null)
                            {
                                BufferLogger.getInstance().toLog("APIResult return success but with values null, throwing exception...");
                                throw new APIException(ErrorCodes.GENERIC_CODE.GENERAL_ERROR, ErrorCodes.SPECIFIC_CODES.GENERAL_ERROR, "Error in reading user configuration from server");
                            }
                            else if (!apiResult.Values.ContainsKey("SignatureInfo"))
                            {
                                BufferLogger.getInstance().toLog("APIResult return success but with SigInfo null, throwing exception...");
                                throw new APIException(ErrorCodes.GENERIC_CODE.GENERAL_ERROR, ErrorCodes.SPECIFIC_CODES.GENERAL_ERROR, "Error in reading user configuration from server");
                            }
                        }

                        sigInfo = JsonConvert.DeserializeObject<SignatureInfo>(apiResult.Values["SignatureInfo"]);
                        BufferLogger.getInstance().toLog("APIResult return success, SigInfo is OK, start decoding...");

                        URLParam urlParam = URLParam.initFromEncoded(sigInfo.ImageBase64);
                        sigInfo.ImageBase64 = urlParam.encodedValue;

                        sigInfo.Chain = new List<Org.BouncyCastle.X509.X509Certificate>();

                        int totalChain = int.Parse(apiResult.Values["totalChain"]);
                        for (int i = 0; i < totalChain; i++)
                        {
                            string certString = apiResult.Values["CERT_" + i];
                            byte[] certBytes = Convert.FromBase64String(certString);
                            X509Certificate cert = new X509CertificateParser().ReadCertificate(certBytes);
                            sigInfo.Chain.Add(cert);
                        }

                        sigInfo.Contact = URLParam.initFromEncoded(sigInfo.Contact).decodedValue;

                        BufferLogger.getInstance().toLog("SigInfo was built successfully!");

                        // V4.2 Override Signature info with localy provided signature format 

                        if (sigFormat != null)
                        {
                            Utils.Utils.InitFromSigInfo(sigFormat, sigInfo);
                        }
                        // -------------------------------------------------------------

                        ClientSession.Put(cuID, sigInfo);

                        BufferLogger.getInstance().toLog("SigInfo stored in client session");
                    }
                    else
                    {
                        BufferLogger.getInstance().toLog("Session exists, using existing siginfo");
                        sigInfo = ClientSession.Get(cuID);
                    }

                    //-- Return the signed PDF file 
                    return signer.sign(fileIn, sigInfo, wsData);
                }
                catch (APIException ex1)
                {
                    BufferLogger.getInstance().toLog("Exception was thrown," + ex1.ToString());
                    throw ex1;
                }
                catch (Exception ex)
                {
                    BufferLogger.getInstance().toLog("Exception was thrown, " + ex.Message);
                    throw new APIException(ErrorCodes.GENERIC_CODE.GENERAL_ERROR, ErrorCodes.SPECIFIC_CODES.GENERAL_ERROR, "Fail to Sign file " + ex.Message);
                }
            }
        }


        /**********************************************************************************************************************
        * 
        * Get the web service status
        * 
        **********************************************************************************************************************/


        public APIResult Status()
        {
            BufferLogger.getInstance().toLog("@PSSignerAPI.Status");
            try
            {
                BufferLogger.getInstance().toLog("Call api/sign/status...");

                // try to primary 
                string rv = null;

                try
                {
                    rv = HttpUtils.Post(this.primaryServerURL + String.Format("api/sign/status"));
                    rv = rv.Replace("\"", string.Empty);
                }
                catch(Exception e)
                {
                    try
                    {
                        if (this.secondaryServerURL != null)
                        {
                            rv = HttpUtils.Post(this.primaryServerURL + String.Format("api/sign/status"));
                            rv = rv.Replace("\"", string.Empty);
                        }

                    }
                    catch (Exception e2)
                    {
                        rv = null;
                    }
                }

                if(rv == null)
                {
                    return new APIResult(ErrorCodes.SPECIFIC_CODES.API_UNABLE_TO_CONNECT_TO_SERVER, "Client API was unable to connect to (both) server");
                }
                else
                {
                    BufferLogger.getInstance().toLog("Building API Result... ");
                    APIResult apiResrv = new APIResult(rv);

                    if (!apiResrv.IsSuccess())
                    {
                        BufferLogger.getInstance().toLog("API Result return with Error : " + apiResrv.getResultString());
                    }
                    BufferLogger.getInstance().toLog("Return API Result with Error");
                    return new APIResult(rv);
                }
                
            }
            catch (Exception ex)
            {
                BufferLogger.getInstance().toLog("Exception was thrown: " + ex.Message);
                return new APIResult(Secure.Logic.Utils.ErrorCodes.SPECIFIC_CODES.GENERAL_ERROR, ex.Message, String.Empty);
            }
        }

        /**********************************************************************************************************************
        * 
        * Login API call, this is a call for getting the token for all future calls 
        * 
        **********************************************************************************************************************/

        public APIResult Login(string appID, string appKey)
        {
            BufferLogger.getInstance().toLog("@PSSignerAPI.Login");
            try
            {
                //-- Initilaize Login Params:
                if (string.IsNullOrEmpty(appID))
                {
                    BufferLogger.getInstance().toLog("APPID is null of empty, throwing exception...");
                    throw new APIException(ErrorCodes.GENERIC_CODE.INPUT_VALIDATION_CODE, ErrorCodes.SPECIFIC_CODES.INPUT_VALIDATION_PARAM_IS_NULL_OR_EMPTY, "API id can't be null");
                }

                if (string.IsNullOrEmpty(appKey))
                {
                    BufferLogger.getInstance().toLog("APPKEY is null of empty, throwing exception...");
                    throw new APIException(ErrorCodes.GENERIC_CODE.INPUT_VALIDATION_CODE, ErrorCodes.SPECIFIC_CODES.INPUT_VALIDATION_PARAM_IS_NULL_OR_EMPTY, "API key can't be null");
                }

                BufferLogger.getInstance().toLog("Initiating parameters...");
                URLParam UserNameURLParam = URLParam.initFromDecoded(appID);
                URLParam PasswordURLParam = URLParam.initFromDecoded(appKey);
                BufferLogger.getInstance().toLog("OK");

                string rv = null;

                try
                {
                    BufferLogger.getInstance().toLog("Calling api/sign/login for PRIMARY server... ");
                    string s = primaryServerURL + String.Format("api/sign/login/{0}/{1}", UserNameURLParam.encodedValue, PasswordURLParam.encodedValue);
                    rv = HttpUtils.Post(s);
                    rv = rv.Replace("\"", string.Empty);

                    this.activeServerURL = primaryServerURL;
                    this.noneActiveServerURL = secondaryServerURL;

                    BufferLogger.getInstance().toLog("OK");
                }
                catch (Exception e)
                {
                    if(secondaryServerURL != null)
                    {
                        try
                        {
                            BufferLogger.getInstance().toLog("Calling api/sign/login for SECONDARY server... ");
                            string s = secondaryServerURL + String.Format("api/sign/login/{0}/{1}", UserNameURLParam.encodedValue, PasswordURLParam.encodedValue);
                            rv = HttpUtils.Post(s);
                            rv = rv.Replace("\"", string.Empty);

                            this.activeServerURL = secondaryServerURL;
                            this.noneActiveServerURL = primaryServerURL;


                            BufferLogger.getInstance().toLog("OK");
                        }
                        catch (Exception e2)
                        {
                            rv = null;
                        }
                    }
                }

                BufferLogger.getInstance().toLog("Building API Result...");
                APIResult apiResrv = null;
                if (rv == null)
                {
                    apiResrv = new APIResult(ErrorCodes.SPECIFIC_CODES.API_UNABLE_TO_CONNECT_TO_SERVER);
                }
                else
                {
                    apiResrv = new APIResult(rv);
                }
                BufferLogger.getInstance().toLog("OK");

                if (!apiResrv.IsSuccess())
                {
                    BufferLogger.getInstance().toLog("API Result return with Error : " + apiResrv.getResultString());
                }

                return apiResrv;
            }
            
            catch (Exception ex)
            {
                BufferLogger.getInstance().toLog("Exception was thrown: " + ex.Message);
                throw new APIException(ErrorCodes.GENERIC_CODE.GENERAL_ERROR, ErrorCodes.SPECIFIC_CODES.GENERAL_ERROR, ex.Message);
            }
        }
    }
}
